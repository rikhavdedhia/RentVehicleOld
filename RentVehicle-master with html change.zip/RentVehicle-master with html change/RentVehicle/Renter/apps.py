from django.apps import AppConfig


class RenterConfig(AppConfig):
    name = 'Renter'
