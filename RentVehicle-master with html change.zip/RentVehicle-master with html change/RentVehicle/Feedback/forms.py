# from django import forms
# from Feedback import models
#
# class GetFeedback(forms.ModelForm):
#     class Meta:
#         model = models.Feedback
#         filds = ['rating','description']
