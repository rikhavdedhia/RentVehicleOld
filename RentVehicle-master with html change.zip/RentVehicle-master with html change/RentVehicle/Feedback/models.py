# from django.db import models
# from dropdowndb.models import  Rating
#
# # Create your models here.
# VehicleFeedback(models.Model):
#     vehicle = models.ForeignKey(Vehicle, on_delete=models.CASCADE)
#     rating = models.ForeignKey(dmodels.Rating, on_delete=models.CASCADE,null=True)
#     description = models.TextField(editable=False)
