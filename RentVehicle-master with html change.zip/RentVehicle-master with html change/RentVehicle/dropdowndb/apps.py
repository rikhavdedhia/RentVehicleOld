from django.apps import AppConfig


class DropdowndbConfig(AppConfig):
    name = 'dropdowndb'
